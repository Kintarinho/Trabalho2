package com.example.trabalhofacul;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edLarguraA;
    private EditText edLarguraB;
    private EditText edAlturaA;
    private EditText edAlturaB;
    private TextView tvPerimetro;
    private TextView tvArea;
    private Button btCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa as views
        edLarguraA = findViewById(R.id.edLarguraA);
        edLarguraB = findViewById(R.id.edLarguraB);
        edAlturaA = findViewById(R.id.edAlturaA);
        edAlturaB = findViewById(R.id.edAlturaB);
        tvPerimetro = findViewById(R.id.tvPerimetro);
        tvArea = findViewById(R.id.tvArea);
        btCalcular = findViewById(R.id.btCalcular);

        // Define o listener do botão calcular
        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("DEBUG", "Botão Calcular foi clicado");
                calcular();
            }
        });
    }

    private void calcular() {
        String larguraAString = edLarguraA.getText().toString();
        String larguraBString = edLarguraB.getText().toString();
        String alturaAString = edAlturaA.getText().toString();
        String alturaBString = edAlturaB.getText().toString();

        // Validação de campos vazios
        if (larguraAString.isEmpty() || larguraBString.isEmpty() || alturaAString.isEmpty() || alturaBString.isEmpty()) {
            tvPerimetro.setText("Preencha todos os campos");
            tvArea.setText("");
            return;
        }

        // Conversão de valores
        double larguraA = Double.parseDouble(larguraAString);
        double larguraB = Double.parseDouble(larguraBString);
        double alturaA = Double.parseDouble(alturaAString);
        double alturaB = Double.parseDouble(alturaBString);

        // Cálculos
        double perimetro = larguraA + larguraB + alturaA + alturaB;
        double area = larguraA * alturaA;

        // Exibe resultados
        tvPerimetro.setText(String.format("PERÍMETRO: %.2f", perimetro));
        tvArea.setText(String.format("ÁREA: %.2f", area));
    }
}
